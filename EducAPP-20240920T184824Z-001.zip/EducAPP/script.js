const questions = [
    {
        question: "Una fábrica produce 15 cajas con 8 botellas de agua cada una. Si venden 92 botellas, ¿cuántas botellas quedan en la fábrica?",
        options: ["24", "28", "30", "20"],
        correctAnswer: "28"
    },
    {
        question: "Si en un examen cada respuesta correcta suma 5 puntos y cada incorrecta resta 2 puntos, ¿cuántos puntos obtiene un estudiante que acierta 8 preguntas y se equivoca en 6?",
        options: ["28", "30", "26", "22"],
        correctAnswer: "28"
    },
    {
        question: "Ana tiene  x pesos. Si recibe 3x+2 pesos más, ¿cuál es la expresión que representa su nuevo total de dinero?",
        options: ["4x+2", "3x+2", "3x+x+2", "x^2+3x+2"],
        correctAnswer: "4x+2"
    },
    {
        question: "Un rectángulo tiene un perímetro de 20 cm. Si uno de sus lados mide 6 cm, ¿cuánto mide el otro lado?",
        options: ["6 cm", "12 cm", "8 cm", "4 cm"],
        correctAnswer: "4 cm"
    },
    {
        question: "Un tren recorre 150 km en 3 horas. ¿Cuál es la velocidad promedio del tren?",
        options: ["60 Km/h", "50 km/h", "45 km/h", "55 km/h"],
        correctAnswer: "50 km/h"
    },
    {
        question: "En una tienda, un descuento del 20% se aplica a una chaqueta que cuesta $50.000. ¿Cuál es el precio después del descuento?",
        options: ["$40.000", "$10.000", "$30.000", "$45.000"],
        correctAnswer: "$40.000"
    },
    {
        question: "Si 2a+5=13, ¿cuál es el valor de a?",
        options: ["4", "2", "6", "5"],
        correctAnswer: "4"
    },
    {
        question: "Un agricultor divide su terreno en 4 partes iguales. Si el terreno total mide 320 metros cuadrados, ¿cuál es el área de cada parte?",
        options: ["80 m²", "70 m²", "75 m²", "60 m²"],
        correctAnswer: "80 m²"
    },
    {
        question: "Si el precio de un artículo aumenta un 10% y luego disminuye un 10%, ¿cuál es el precio final en relación con el precio original?",
        options: ["Igual al original", "99% del original", "101% del original", "90% del original"],
        correctAnswer: "99% del original"
    },
    {
        question: "En un salón, hay 12 mesas y en cada mesa 4 sillas. Si se quitan 2 mesas, ¿cuántas sillas quedan?",
        options: ["40", "48", "32", "36"],
        correctAnswer: "40"
    },
    {
        question: "¿Cuál de las siguientes figuras tiene mayor área?",
        options: ["Un círculo con radio de 5 cm", "Un cuadrado con lado de 8 cm", "Un rectángulo de 6 cm por 7 cm", "Un triángulo con base 10 cm y altura 6 cm"],
        correctAnswer: "Un círculo con radio de 5 cm"
    },
    {
        question: "En una carrera, Juan va a 6 km/h y Pedro a 8 km/h. Si ambos parten al mismo tiempo, ¿cuánto tiempo le tomará a Pedro alcanzar a Juan si Juan lleva una ventaja de 3 km?",
        options: ["1.5 horas", "2 horas", "1 hora", "3 horas"],
        correctAnswer: "1.5 horas"
    },
    {
        question: "Un producto cuesta $80.000 y tiene un descuento del 25%. ¿Cuál es el precio final?",
        options: ["$60.000", "$65.000", "$70.000", "$55.000"],
        correctAnswer: "$60.000"
    },
    {
        question: "Un tanque tiene capacidad para 300 litros de agua. Si ya tiene 180 litros, ¿cuántos litros más necesita para llenarse?",
        options: ["100 litros", "120 litros", "110 litros", " 90 litros"],
        correctAnswer: "120 litros"
    },
    {
        question: "Si y = 3x - 4   y   x=2, ¿cuál es el valor de y?",
        options: ["4", "2", "3", "6"],
        correctAnswer: "2"
    },
    {
        question: "En un supermercado, 5 libras de manzanas cuestan $12.000. ¿Cuánto cuestan 8 libras?",
        options: ["$20.000", "$19.200", "$16.500", "$14.000"],
        correctAnswer: "$19.200"
    },
    {
        question: "Si 2x-3=7, ¿cuál es el valor de x?",
        options: ["4", "2", "6", "5"],
        correctAnswer: "5"
    },
    {
        question: "Un número se multiplica por 2 y luego se suma 5, dando como resultado 19. ¿Cuál es el número original?",
        options: ["7", "8", "6", "9"],
        correctAnswer: "7"
    },
    {
        question: " Si el perímetro de un cuadrado es 32 cm, ¿cuál es la longitud de cada lado?",
        options: ["6 cm", "7 cm", "8 cm", "9 cm"],
        correctAnswer: "8 cm"
    },
    {
        question: "Un trabajador recibe $20,000 por hora. Si trabaja 5 horas y luego 3 horas extras con un 50% más de pago, ¿cuánto gana en total?",
        options: ["$160,000", "$170,000", "$180,000", "$190,000"],
        correctAnswer: "$190,000"
    },
    {
        question: "En un juego, si lanzas dos dados, ¿cuál es la probabilidad de obtener una suma de 7?",
        options: ["1/6", "1/12", "1/8", "1/4"],
        correctAnswer: "1/6"
    },
    {
        question: "Si a=2b y b=3c, ¿cuál es la relación entre a y c?",
        options: ["a = 6c", "a = 2c", "a = 3c", "a = c^2"],
        correctAnswer: "a = 6c"
    },
    {
        question: "Una pizza se divide en 8 partes iguales. Si te comes 3 partes, ¿qué fracción de la pizza te queda?",
        options: ["5/8", "3/8", "1/2", "1/4"],
        correctAnswer: "5/8"
    },
    {
        question: "Si un carro recorre 150 km en 2 horas y 30 minutos, ¿cuál es su velocidad promedio?",
        options: ["60 km/h", "65 km/h", "70 km/h", "75 km/h"],
        correctAnswer: "60 km/h"
    },
    {
        question: "Una caja contiene 3 bolas rojas, 5 bolas azules y 2 bolas verdes. Si se saca una bola al azar, ¿cuál es la probabilidad de que sea azul?",
        options: ["1/2", "1/3", "2/5", "1/4"],
        correctAnswer: "1/2"
    },
    {
        question: "Si una tienda vende 3 camisetas por $90,000, ¿cuánto costarían 5 camisetas?",
        options: ["$140.000", "$150.000", "$160.000", "$170.000"],
        correctAnswer: "$150.000"
    },
    {
        question: "Si un tren viaja a 80 km/h, ¿cuántos kilómetros recorrerá en 4 horas?",
        options: ["240 km", "320 km", "260 km", "300 km"],
        correctAnswer: "320 km"
    },
    {
        question: "En una caja hay 10 bolas numeradas del 1 al 10. ¿Cuál es la probabilidad de sacar un número par?",
        options: ["1/2", "1/3", "1/4", "3/5"],
        correctAnswer: "1/2"
    },
    {
        question: "Si una familia consume 150 litros de agua por día, ¿cuántos litros consumirá en una semana?",
        options: ["1050 litros", "900 litros", "1200 litros", "1000 litros"],
        correctAnswer: "1050 litros"
    },
    {
        question: "Un terreno rectangular tiene un área de 200 m² y un ancho de 10 m. ¿Cuál es la longitud del terreno?",
        options: ["15 m", "20 m", "25 m", "30 m"],
        correctAnswer: "20 m"
    },
    // Añadir más preguntas aquí
];

let currentQuestionIndex = 0;
let correctAnswersCount = 0;
let incorrectAnswersCount = 0;
let shuffledQuestions = [];

document.getElementById('start-button').addEventListener('click', startGame);
document.getElementById('credits-button').addEventListener('click', showCredits); // NUEVO: Evento para mostrar créditos
document.getElementById('toggle-music').addEventListener('click', toggleMusic);
document.getElementById('toggle-music-game').addEventListener('click', toggleMusic);
document.getElementById('next-question').addEventListener('click', () => {
    if (document.querySelector('.option.correct, .option.incorrect')) {
        showNextQuestion();
    }
});
document.getElementById('restart-game').addEventListener('click', restartGame);
document.getElementById('return-to-menu').addEventListener('click', returnToMenu);
document.getElementById('return-to-menu-from-credits').addEventListener('click', returnToMenuFromCredits);

function startGame() {
    shuffleQuestions();
    toggleView('main-menu', 'game-container');
    showQuestion();
}

function shuffleQuestions() {
    shuffledQuestions = questions.sort(() => Math.random() - 0.5);
    currentQuestionIndex = 0;
    correctAnswersCount = 0;
    incorrectAnswersCount = 0;
    updateQuestionCounter();
}

function showQuestion() {
    const question = shuffledQuestions[currentQuestionIndex];
    const optionsContainer = document.getElementById('options-container');
    document.getElementById('question-text').textContent = question.question;
    optionsContainer.innerHTML = '';

    question.options.forEach(option => {
        const button = document.createElement('button');
        button.classList.add('option');
        button.textContent = option;
        button.addEventListener('click', () => selectAnswer(button, question.correctAnswer));
        optionsContainer.appendChild(button);
    });

    updateQuestionCounter(); // NUEVO: Actualizar el contador de preguntas
}

function selectAnswer(selectedButton, correctAnswer) {
    document.querySelectorAll('.option').forEach(button => {
        button.disabled = true;
        if (button.textContent === correctAnswer) {
            button.classList.add('correct');
        }
    });

    if (selectedButton.textContent === correctAnswer) {
        correctAnswersCount++;
        playSound('correct-sound');
        showPopup('¡Correcto!', 'correct');
    } else {
        incorrectAnswersCount++;
        selectedButton.classList.add('incorrect');
        playSound('incorrect-sound');
        showPopup('¡Incorrecto!', 'incorrect');
    }

    document.getElementById('next-question').classList.remove('hidden');
}

function showNextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < shuffledQuestions.length) {
        showQuestion();
        document.getElementById('next-question').classList.add('hidden');
    } else {
        if (correctAnswersCount >= 20) {
            playSound('victory-sound'); // Sonar el audio de victoria
            showPopup('¡Felicidades! Has acertado más de 20 preguntas.', 'victory');
        }
        showScoreSummary();
    }
}

function showScoreSummary() {
    toggleView('game-container', 'score-summary');
    const totalQuestions = shuffledQuestions.length;
    const percentage = Math.round((correctAnswersCount / totalQuestions) * 100);
    
    document.getElementById('correct-answers').textContent = `Respuestas Correctas: ${correctAnswersCount}`;
    document.getElementById('incorrect-answers').textContent = `Respuestas Incorrectas: ${incorrectAnswersCount}`;
    document.getElementById('total-questions').textContent = `Total de Preguntas: ${totalQuestions}`;
    document.getElementById('percentage').textContent = `Porcentaje de Aciertos: ${percentage}%`;

    // Agregar el evento para el botón de música en resumen de resultados
    document.getElementById('toggle-music').addEventListener('click', toggleMusic);
}

function restartGame() {
    toggleView('score-summary', 'game-container');
    shuffleQuestions();
    showQuestion();
}

function returnToMenu() {
    toggleView('score-summary', 'main-menu');
}

function returnToMenuFromCredits() {
    toggleView('credits-window', 'main-menu');
}

// NUEVO: Función para mostrar la ventana de créditos
function showCredits() {
    toggleView('main-menu', 'credits-window');
}

function toggleView(hide, show) {
    document.getElementById(hide).classList.add('hidden');
    document.getElementById(show).classList.remove('hidden');
}

function playSound(soundId) {
    const sound = document.getElementById(soundId);
    sound.currentTime = 0;
    sound.play();
}

function toggleMusic() {
    const music = document.getElementById('background-music');
    const musicIcon = document.getElementById('music-icon');
    const musicIconGame = document.getElementById('music-icon-game');
    if (music.paused) {
        music.play();
        musicIcon.src = 'music-on-icon.png';
        musicIconGame.src = 'music-on-icon.png';
    } else {
        music.pause();
        musicIcon.src = 'music-off-icon.png';
        musicIconGame.src = 'music-off-icon.png';
    }
}

function showPopup(message, status) {
    const popup = document.createElement('div');
    popup.classList.add('popup', status); // Añadimos la clase correcta o incorrecta
    popup.textContent = message;
    document.body.appendChild(popup);

    // Añadimos la clase 'show' para la animación de entrada
    setTimeout(() => {
        popup.classList.add('show');
    }, 10); // Un pequeño delay para asegurar la animación

    // Después de 2 segundos, el popup se oculta con la animación
    setTimeout(() => {
        popup.classList.add('hide');
    }, 2000);

    // Removemos el pop-up del DOM después de la animación de salida
    setTimeout(() => {
        popup.remove();
    }, 2500); // Ajusta el tiempo para que coincida con la duración de la animación
}

function updateQuestionCounter() { // NUEVO: Función para actualizar el contador de preguntas
    document.getElementById('question-counter').textContent = `Pregunta ${currentQuestionIndex + 1} de ${shuffledQuestions.length}`;
}